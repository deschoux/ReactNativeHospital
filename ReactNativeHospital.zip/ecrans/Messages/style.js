import { FlatList, StyleSheet } from "react-native";
import { COLORS, PADDING } from "../../outils/constantes";

const MessagesList = StyleSheet.create({
  root: {
    paddingVertical: PADDING.vertical,
    paddingHorizontal: PADDING.horizontal,
  },

  // },
});

export default styles;
