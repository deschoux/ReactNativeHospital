export const FakeSymptome = [
  {
    id: 1,
    imgSymptome: "img1.png",
    libelle: "Mal de tête",
  },

  {
    id: 2,
    imgSymptome: "img2.png",
    libelle: "Fièvre",
  },

  {
    id: 3,
    imgSymptome: "img3.png",
    libelle: "Rhume",
  },
  {
    id: 4,
    imgSymptome: "img4.png",
    libelle: "Mal de gorge",
  },
];
