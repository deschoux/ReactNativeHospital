export const fakeSettings = [
  { id: 1, libelle: "Profil" },
  { id: 2, libelle: "Mes documents" },
  { id: 3, libelle: "Mes consultations" },
  { id: 4, libelle: "Mes consultations en Visio" },
  { id: 5, libelle: "Mes rendez-vous" },
  { id: 6, libelle: "Une Urgence" },
  { id: 7, libelle: "Mes assurances" },
  { id: 8, libelle: "Pharmacie de garde" },
  { id: 9, libelle: "Appelez Ambulance" },
  { id: 10, libelle: "Numéros Utiles" },
  { id: 11, libelle: "Mon Livre Santé" },
  { id: 12, libelle: "Me déconnecter" },
  // Ajoutez d'autres entrées selon vos données
];

export default fakeSettings;
