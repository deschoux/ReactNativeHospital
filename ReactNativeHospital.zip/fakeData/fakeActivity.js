export const FakeActivity = [
  {
    id: 1,
    mainText: "Docteur à domicile",
    subText: "Votre docteur à domicile",
  },

  {
    id: 2,
    mainText: "Clinique pour vous",
    subText: "Clinique à votre service",
  },
  {
    id: 3,
    mainText: "Traitement longue durée",
    subText: "Votre traitement ALD",
  },
  {
    id: 4,
    mainText: "Traitement longue durée",
    subText: "Votre traitement ALD",
  },
  {
    id: 5,
    mainText: "Traitement longue durée",
    subText: "Votre traitement ALD",
  },
  {
    id: 6,
    mainText: "Traitement longue durée",
    subText: "Votre traitement ALD",
  },
];
