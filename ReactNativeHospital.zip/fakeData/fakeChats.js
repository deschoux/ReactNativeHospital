export const fakeChats = [
  {
    id: "b21e784b-be8d-4b59-a325-d36fe71e6039",
    fullname: "Muriel Hubert",
    last_message:
      "quis esse voluptate occaecat cillum id quis Lorem est magna ad voluptate sit magna",
    date: "2023-08-20T04:25:43.263Z",
  },
  {
    id: "41b8064c-c151-44f0-b90c-91dcadca5be1",
    fullname: "Amande Bertrand",
    last_message: "eu sunt",
    date: "2023-06-03T03:28:32.021Z",
  },
  {
    id: "10c3e2ee-a70b-4f0e-bcd6-e84093aa3dd4",
    fullname: "Alix Aubert",
    last_message: "nulla fugiat aliqua ut cupidatat enim incididunt",
    date: "2023-08-05T17:14:27.713Z",
  },
  {
    id: "8d79a477-afb5-4742-8960-6dd69429ecb1",
    fullname: "Alix Dubois",
    last_message: "non ullamco excepteur laboris dolor do reprehenderit Lorem",
    date: "2024-01-04T20:30:21.919Z",
  },
  {
    id: "abf4b458-493d-4101-95b5-003a71ff536b",
    fullname: "Foulques Maillard",
    last_message: "commodo dolor",
    date: "2023-07-08T20:08:07.057Z",
  },
  {
    id: "003c462d-b24c-45f6-81ac-0b2228891e22",
    fullname: "Agrippin Baron",
    last_message: "consectetur in qui excepteur aute veniam",
    date: "2023-08-15T06:34:39.224Z",
  },
  {
    id: "3a213dff-5c26-4b95-a1eb-b295b50936cd",
    fullname: "Herluin Philippe",
    last_message:
      "velit occaecat occaecat veniam do anim ea velit pariatur laborum id aliqua",
    date: "2024-02-16T15:21:30.385Z",
  },
  {
    id: "c1340477-98aa-4b32-8806-9ec92d00761a",
    fullname: "Ève Poirier",
    last_message:
      "eu in sunt tempor amet excepteur mollit tempor esse ut id consectetur",
    date: "2023-05-29T21:36:02.075Z",
  },
  {
    id: "729e857e-07db-493d-83f4-be455f457191",
    fullname: "Charlaine Aubert",
    last_message: "",
    date: "2024-02-04T12:24:24.641Z",
  },
  {
    id: "fdd713dd-a410-4182-8d4e-febf618ce55d",
    fullname: "Yvette Muller",
    last_message: "",
    date: "2024-01-09T00:53:24.929Z",
  },
  {
    id: "2a62a539-5f86-4efd-892d-db3062c8dd76",
    fullname: "Vital Dubois",
    last_message:
      "reprehenderit adipisicing proident exercitation labore esse in incididunt nulla consectetur eu",
    date: "2023-04-29T11:59:25.695Z",
  },
  {
    id: "e298b1db-1e94-49c5-8872-335801629de0",
    fullname: "Acacie Barre",
    last_message:
      "quis irure ea aute velit nulla sunt sunt labore laboris ipsum in esse ea Lorem do",
    date: "2023-07-20T19:31:31.739Z",
  },
  {
    id: "19e40ee8-6493-4122-9127-203d7a65240a",
    fullname: "Abdon Caron",
    last_message:
      "veniam labore sint qui ea aute dolore nisi id sit proident incididunt enim nulla",
    date: "2023-12-09T00:04:50.011Z",
  },
  {
    id: "4c6c46fd-c529-4daf-83b1-bb980b4a78ac",
    fullname: "Adalsinde Dumont",
    last_message:
      "duis reprehenderit sunt incididunt tempor incididunt nostrud officia amet Lorem deserunt enim pariatur fugiat nulla tempor",
    date: "2023-06-04T05:13:16.387Z",
  },
  {
    id: "8f979918-9042-4025-aab5-caf8bcee7263",
    fullname: "Claudien Remy",
    last_message:
      "duis amet laboris labore velit commodo in eiusmod culpa qui dolor",
    date: "2024-01-21T08:32:27.754Z",
  },
  {
    id: "ab5848c9-220e-4479-8e72-f319b7bb34cc",
    fullname: "Nicolas Barbier",
    last_message: "deserunt mollit consequat excepteur culpa labore laborum",
    date: "2024-02-19T09:11:35.531Z",
  },
  {
    id: "af502ab4-fe10-4d45-99f1-3c371cb0d68c",
    fullname: "Judith Bourgeois",
    last_message:
      "occaecat eiusmod duis sint deserunt aliquip exercitation consectetur ad ullamco in irure elit mollit enim",
    date: "2023-09-06T22:11:17.341Z",
  },
  {
    id: "eb23e923-8c57-4662-8659-ca49736b8346",
    fullname: "Reine Leroux",
    last_message: "quis mollit incididunt laborum qui quis culpa nulla",
    date: "2024-03-27T10:07:51.624Z",
  },
  {
    id: "37e9b2f3-39fe-4bef-a3c0-9dea8025770f",
    fullname: "Geoffroy Perrot",
    last_message:
      "dolore eu dolor commodo dolor incididunt esse ex irure tempor sint esse",
    date: "2023-05-04T15:13:00.603Z",
  },
  {
    id: "da0c67e8-a738-42df-a7e2-9f075943843d",
    fullname: "Ozanne Julien",
    last_message: "mollit irure exercitation esse deserunt culpa anim in",
    date: "2023-12-18T01:17:52.679Z",
  },
  {
    id: "cb8ad664-f123-4a48-bc9a-4ef36dee025b",
    fullname: "Aymardine Fabre",
    last_message: "est sunt laborum anim ipsum",
    date: "2023-06-13T20:11:53.701Z",
  },
  {
    id: "ded4c2cc-594a-4f71-90ac-a717a12a794b",
    fullname: "Avoye Maillard",
    last_message:
      "do dolore ut nulla culpa incididunt fugiat exercitation velit incididunt tempor proident excepteur nulla veniam exercitation ad",
    date: "2023-09-27T05:12:01.531Z",
  },
  {
    id: "5e1faf35-b8c6-4aa4-ad5b-ed88120278c2",
    fullname: "Arian Rousseau",
    last_message: "nostrud labore sit labore commodo aute sunt proident eu",
    date: "2023-10-23T15:07:53.819Z",
  },
  {
    id: "3cc0ec1f-f4e2-440f-a97f-8f359c6f311b",
    fullname: "Aude Gautier",
    last_message:
      "officia pariatur fugiat excepteur et duis ea sit pariatur sit mollit labore proident duis",
    date: "2024-02-28T17:38:14.045Z",
  },
  {
    id: "45ab6dae-22e9-4b90-b3f8-29939bde8bd6",
    fullname: "Mélisande Barbier",
    last_message:
      "culpa exercitation reprehenderit tempor et fugiat ex dolor fugiat ex minim duis exercitation non labore irure incididunt",
    date: "2023-11-30T02:35:15.786Z",
  },
  {
    id: "7c7cec65-1b6e-4c57-9409-cc212c75ba08",
    fullname: "Mireille Rousseau",
    last_message:
      "proident mollit deserunt veniam adipisicing consequat magna duis consequat tempor minim incididunt aliquip aliqua ut eu et officia",
    date: "2024-04-14T18:54:11.393Z",
  },
  {
    id: "28e909c5-5ce6-4662-8ba9-ad70d875c555",
    fullname: "Fulgence Lefebvre",
    last_message:
      "sit nostrud aute incididunt dolor aliquip minim proident commodo deserunt aute cupidatat ea ipsum quis aliqua fugiat non",
    date: "2023-10-19T20:25:48.543Z",
  },
  {
    id: "faca92c3-cb7e-4f7f-96f1-581b57cb79b5",
    fullname: "Eva Clement",
    last_message: "aliqua culpa cillum dolore esse dolor in dolore enim",
    date: "2024-04-06T07:02:57.433Z",
  },
  {
    id: "4095c479-4f2e-4743-8ca2-3c067cab6790",
    fullname: "Alpinien Carre",
    last_message:
      "et cupidatat quis eiusmod et fugiat aute in nulla sunt Lorem exercitation nisi qui do excepteur aliquip adipisicing irure laboris",
    date: "2024-03-25T18:43:26.435Z",
  },
  {
    id: "3a2739f4-8381-461a-9cec-d90949cd5eb8",
    fullname: "Thibault Berger",
    last_message:
      "laboris aute non deserunt mollit ea non sunt est reprehenderit laboris eu",
    date: "2023-08-29T04:32:06.366Z",
  },
  {
    id: "1623bb8d-ed2d-4fe7-95f5-37ce62b3ff31",
    fullname: "Théodora Fernandez",
    last_message:
      "esse ipsum reprehenderit ipsum do ipsum culpa labore nulla minim minim et occaecat excepteur ea",
    date: "2023-11-06T02:07:07.711Z",
  },
  {
    id: "12ad4ed4-fbe8-44c4-ad23-58232c6d4efc",
    fullname: "Jason Marie",
    last_message:
      "irure dolor exercitation amet ut minim aliquip non mollit magna reprehenderit et",
    date: "2023-08-05T05:37:01.979Z",
  },
  {
    id: "3ff07f32-7afb-4ff9-9d89-f68660e195b6",
    fullname: "Falba Bertrand",
    last_message: "sunt",
    date: "2023-10-08T20:29:35.727Z",
  },
  {
    id: "7e9e9a6b-070a-4714-a714-9b490dddb5c8",
    fullname: "Judith Faure",
    last_message: "dolore Lorem voluptate nisi velit Lorem",
    date: "2023-05-16T17:15:23.611Z",
  },
  {
    id: "aba99544-4760-4a1e-b6ea-e46884344bf4",
    fullname: "Amélien Renard",
    last_message:
      "aute mollit magna ea magna est deserunt excepteur aliqua quis irure sunt reprehenderit cillum dolore amet veniam commodo aliquip consectetur",
    date: "2023-08-20T18:18:47.735Z",
  },
  {
    id: "d36300bd-70b0-423a-b794-609433e99370",
    fullname: "Audouin Garcia",
    last_message: "magna occaecat occaecat",
    date: "2023-12-29T05:47:26.169Z",
  },
  {
    id: "a51612a4-2a25-44dc-8a7f-0ee8e23dccca",
    fullname: "Clarence Moulin",
    last_message:
      "in nostrud id qui deserunt dolor nulla Lorem eu amet ea ipsum irure qui deserunt incididunt amet adipisicing ex",
    date: "2023-10-06T04:47:49.617Z",
  },
  {
    id: "6bcf358c-2ac8-44df-8ce3-a832b1e21705",
    fullname: "Faustine Prevost",
    last_message: "enim laborum",
    date: "2024-01-04T08:51:56.480Z",
  },
  {
    id: "87f4d6b1-eaca-4868-aff2-0fad01b0a498",
    fullname: "Judith Charles",
    last_message:
      "in amet velit amet ullamco cupidatat eu dolor esse dolore laboris non aliqua officia sunt nostrud aliqua",
    date: "2023-09-11T02:28:04.781Z",
  },
  {
    id: "5395fccc-ba77-4b79-9227-55d05ead7018",
    fullname: "Reybaud Andre",
    last_message: "excepteur pariatur et aliquip",
    date: "2023-05-05T00:14:36.881Z",
  },
  {
    id: "841f21bf-8553-402a-8dc4-01dbb0c2e1f5",
    fullname: "Gautier Dupuy",
    last_message:
      "pariatur commodo nostrud commodo enim cupidatat aliqua et id aliquip reprehenderit ut laboris adipisicing ea culpa eiusmod",
    date: "2024-03-25T01:02:40.080Z",
  },
  {
    id: "dedc8d83-ab80-4ae0-8773-735bb59c7aaf",
    fullname: "Apollinaire Schneider",
    last_message:
      "adipisicing ullamco nulla labore sit anim dolore Lorem tempor ut sit",
    date: "2024-01-13T12:46:28.797Z",
  },
  {
    id: "5ef92a14-6afb-4a21-8795-b4136f52ba82",
    fullname: "Christine Thomas",
    last_message:
      "aliquip Lorem tempor veniam ex elit sunt Lorem sunt ut adipisicing incididunt tempor consectetur tempor cillum magna deserunt",
    date: "2023-12-05T02:24:04.052Z",
  },
  {
    id: "7e1a7717-f1ca-4158-b75c-828bfc7ea18f",
    fullname: "Bénigne Gonzalez",
    last_message:
      "ex sunt ullamco elit sit sit sit commodo reprehenderit ullamco sit in",
    date: "2023-12-03T11:34:54.379Z",
  },
  {
    id: "fe994280-f9c7-4bf9-a926-377b90069aef",
    fullname: "Jérôme Poirier",
    last_message: "aute exercitation reprehenderit eu consectetur Lorem aliqua",
    date: "2023-07-02T08:24:02.481Z",
  },
  {
    id: "5e62aa8a-9326-4169-a78a-97480c5a3158",
    fullname: "Clélie Menard",
    last_message: "ad",
    date: "2023-11-19T11:48:33.008Z",
  },
  {
    id: "83552c27-23db-4944-b8d4-8df6b75a2499",
    fullname: "Gwenaëlle Aubert",
    last_message:
      "do proident sunt nulla aliqua officia ipsum anim ipsum anim irure amet cupidatat id aliqua deserunt elit quis cillum",
    date: "2023-08-27T16:12:07.973Z",
  },
  {
    id: "58f33eb1-9b91-45f1-acb4-627d365a566e",
    fullname: "Arsènie Robin",
    last_message:
      "reprehenderit sit deserunt adipisicing qui do amet aute deserunt aliquip dolor adipisicing culpa aliqua qui cillum laboris qui",
    date: "2024-03-11T21:04:41.875Z",
  },
  {
    id: "02c1bf35-2479-46b2-a9cf-1ec8af934cc4",
    fullname: "Denise Charles",
    last_message: "",
    date: "2023-07-09T08:35:54.631Z",
  },
  {
    id: "d03c5ef8-dbc9-43a8-a467-25d712905e74",
    fullname: "Aurore Roux",
    last_message:
      "commodo culpa nostrud ullamco enim mollit duis dolor id voluptate excepteur amet fugiat veniam ut fugiat",
    date: "2024-01-18T00:15:09.572Z",
  },
];
